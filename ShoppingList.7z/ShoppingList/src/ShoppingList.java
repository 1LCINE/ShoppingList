import java.io.*;
import java.util.ArrayList;

public class ShoppingList {
    private ArrayList<ArrayList<String>> lists;
    private TextFile textFile;

    public ShoppingList(String filename) throws IOException, IllegalArgumentException, FileException {
        textFile = new TextFile(filename, 'R');
        lists = new ArrayList<>();
        loadLists();
    }

    private void loadLists() throws IOException, FileException {
        String line;
        while ((line = textFile.fromFile()) != null) {
            String[] elements = line.split(";");
            ArrayList<String> list = new ArrayList<>();
            for (int i = 1; i < elements.length; i++) {
                list.add(elements[i].trim()); // Add products to the list, skipping the list number
            }
            lists.add(list);
        }
        textFile.closeFile();
    }


    public ArrayList<String> getList(int listNumber) {
        return lists.get(listNumber - 1); // List number starts from 1
    }

    public int getNumberOfLists() {
        return lists.size();
    }
}
