import java.io.*;
import java.util.ArrayList;
import java.io.IOException;
enum Mode {
    READ,
    WRITE
}


public class Main {
    public static void main(String[] args) {
        try {
            ShoppingList shoppingList = new ShoppingList("file.txt");
            int selectedListNumber = 1; // Change this to select a different list
            if (selectedListNumber <= shoppingList.getNumberOfLists()) {
                ArrayList<String> selectedList = shoppingList.getList(selectedListNumber);
                System.out.println("Lista selezionata:");
                for (String product : selectedList) {
                    System.out.println(product);
                }
            } else {
                System.out.println("Lista non trovata.");
            }
        } catch (IOException | FileException e) {
            e.printStackTrace();
        }
    }
}





